<?php
 
//require_once("Applicatin/Admin/Admin.php");
//require_once("Applicatin/Faculty/Faculty.php");
//require_once("Applicatin/HOD/Hod.php");
header("Location: ../student/Application/views/")


// header("Location: ../student/Application/views/Admin/Admin.php")







?>